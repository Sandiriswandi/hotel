<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan Kamar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="row justify-content-center ">
        <div class="col-lg-6">
            <form class="mt-5">
                <h1 class="text-center mb-5">Pesan Kamar</h1>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Nama Pemesan</label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="inputPassword6" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Jenis Kelamin</label>
                        </div>
                        <div class="col-auto">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Laki-laki
                                </label>
                                </div>
                                <div class="form-check">
                                <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
                                <label class="form-check-label" for="flexRadioDefault2">
                                    Perempuan
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Nomor Identitas</label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="inputPassword6" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Tipe Kamar</label>
                        </div>
                        <div class="col-auto">
                        <select class="form-select" aria-label="Default select example">
                            <option selected>Open this select menu</option>
                            <option value="1">STANDAR</option>
                            <option value="2">DELUXE</option>
                            <option value="3">EXECUTIF</option>
                        </select>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">HARGA</label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="inputPassword6" class="form-control" disabled>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Tanggal Pesan</label>
                        </div>
                        <div class="col-auto">
                            <input type="date" id="inputPassword6" class="form-control" >
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Durasi Menginap</label>
                        </div>
                        <div class="col-auto">
                            <input type="number" id="inputPassword6" class="form-control">
                        </div>
                        <div class="col-auto">
                            <span id="passwordHelpInline" class="form-text">
                            Hari
                            </span>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Termasuk Break Fast</label>
                        </div>
                        <div class="col-auto">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked>
                                <label class="form-check-label" for="flexCheckChecked">
                                    YA
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="inputPassword6" class="col-form-label">Total Bayar</label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="inputPassword6" class="form-control" disabled>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>


