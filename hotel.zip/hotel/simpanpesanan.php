<?php
    $koneksi = mysqli_connect("localhost", "root", "", "db_hotel");
    
    $namapemesan = $_POST['namapemesan'];
    $jeniskelamin = $_POST['jeniskelamin'];
    $noidentitas = $_POST['noidentitas'];
    $tipekamar = explode('|', $_POST['tipekamar'])[0];
    $harga = $_POST['harga'];
    $tanggal = $_POST['tanggal'];
    $durasi = $_POST['durasi'];
    $diskon = $durasi > 3 ? $harga * 0.1 : 0;
    $totalbayar = $_POST['totalbayar'];

    mysqli_query($koneksi, "INSERT INTO pemesanan VALUES ('', '$namapemesan', $noidentitas, '$jeniskelamin', '$tipekamar', '$tanggal', $durasi, $diskon, $totalbayar)");

?>


<table>
    <tr>
        <td>Nama Pemesan</td>
        <td>: <?= $namapemesan; ?></td>
    </tr>
    <tr>
        <td>Nomor Identitas</td>
        <td>: <?= $noidentitas; ?></td>
    </tr>
    <tr>
        <td>Jenis Kelamin</td>
        <td>: <?= $jeniskelamin; ?></td>
    </tr>
    <tr>
        <td>Tipe Kamar</td>
        <td>: <?= $tipekamar; ?></td>
    </tr>
    <tr>
        <td>Durasi Penginapan</td>
        <td>: <?= $durasi; ?></td>
    </tr>
    <tr>
        <td>diskon</td>
        <td>: 10%</td>
    </tr>
    <tr>
        <td>Total Bayar</td>
        <td>: Rp <?= number_format($totalbayar,2)."<br>"; ?></td>
    </tr>
</table>