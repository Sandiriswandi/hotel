<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Hotel BRO</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 15px;
            text-align: center;
        }
        nav {
            background-color: #444;
            padding: 10px;
            text-align: center;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            margin: 0 10px;
            display: inline-block;
        }
        section {
            padding: 20px;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px; 
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Hotel BRO</h1>
    </header>
    <nav>
        <a href="#produk">Produk</a>
        <a href="#daftar-harga">Daftar Harga</a>
        <a href="#tentang-kami">Tentang Kami</a>
        <a href="pesankamar.php">Pesan Kamar</a>
    </nav>
    <section id="produk">
        <h2>Produk</h2>
        <p>Contoh jenis kamar:</p>
        <div class="row">
          <div class="col-md-4">
            <img src="img/standart.jpeg" alt="Standar Room" width="500">
            <h3 class="text-center">Standar</h3>
          </div>
          <div class="col-md-4">
            <img src="img/Deluxe.jpg" alt="Deluxe Room" width="500">
            <h3 class="text-center">Deluxe</h3>
          </div>
          <div class="col-md-4">
            <img src="img/exe.jpg" alt="Executif Room" width="500">
            <h3 class="text-center">Executif</h3>
          </div>
        </div>
    </section>
    <section id="daftar-harga">
        <h2>Daftar Harga</h2>
        <table>
            <tr>
                <th>Jenis Kamar</th>
                <th>Harga per Malam</th>
            </tr>
            <tr>
                <td>Standar</td>
                <td>Rp.500.000</td>
            </tr>
            <tr>
                <td>Deluxe</td>
                <td>Rp.1.500.000</td>
            </tr>
            <tr>
                <td>Executif</td>
                <td>Rp.2.000.000</td>
            </tr>
        </table>
    </section>
    <section id="tentang-kami">
        <h2>Tentang Kami</h2>
        <p>Hotel BRO adalah tempat penginapan yang nyaman dan mewah. Berlokasi di pusat kota, kami menawarkan kamar-kamar dengan fasilitas terbaik.</p>
        <p>Alamat: Jalan SUEPOMO No. 88, Kota Pancor</p>
        <p>No. Telp: 021-000-111</p>
        <p>Email: info@hotelbro.com</p>
    </section>
    <section id="pesan-kamar">
        <h2>Pesan Kamar</h2>
        <p>Silakan mengisi formulir di bawah ini untuk memesan kamar:</p>
        <!-- Formulir pemesanan kamar akan disertakan di sini -->
    </section>
    <footer>
        &copy; 2023 Hotel BRO. All rights reserved.
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
