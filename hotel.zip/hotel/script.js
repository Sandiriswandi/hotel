const lamaMenginap = document.querySelector('#lamaMenginap')
const totalBayar = document.querySelector("#totalBayar")
const totalBayarHidden = document.querySelector("#totalBayarHidden")
const hargaKamar = document.querySelector("#harga")
const hargaHidden = document.querySelector("#hargaHidden")
const msgErrorIdentitas = document.querySelector("#msgErrorIdentitas")

function pilTypeKamar (data) {
    harga = data.value.split('|')[1]

    hargaHidden.value =  harga
    hargaKamar.value = rupiahFormat(harga)
}

function setTotalBayar() {
    let harga = hargaHidden.value || 0
    let lama = lamaMenginap.value
    let discon = 0
    
    let bayar = parseInt(harga*lama)

    if (document.querySelector('#flexCheckChecked').checked) bayar += 80000
    if (lama > 3) bayar = bayar - (bayar * 0.1)

    totalBayarHidden.value = bayar
    totalBayar.value = rupiahFormat(bayar)
}


function rupiahFormat(value) {
    return Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
    }).format(value);   
}

function checkNumber(data) {
    if(data.value.length < 16) 
        msgErrorIdentitas.classList.remove("d-none")
    else if(data.value.length >= 16) 
        msgErrorIdentitas.classList.add("d-none")
}